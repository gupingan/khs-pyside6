"""File: __init__.py.py    Author: 顾平安"""
from .banned_words import BANNED_WORDS
